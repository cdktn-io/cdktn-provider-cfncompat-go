/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CfncompatProviderConfig {
    /**
    * The AWS access key. Can also be sourced from the `AWS_ACCESS_KEY_ID` environment variable, or via a shared credentials file if `profile` is specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#access_key CfncompatProvider#access_key}
    */
    readonly accessKey?: string;
    /**
    * Configuration for assuming an IAM role prior to making AWS API calls.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#assume_role CfncompatProvider#assume_role}
    */
    readonly assumeRole?: CfncompatProviderAssumeRole;
    /**
    * Configuration for assuming an IAM role using a web identity token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#assume_role_with_web_identity CfncompatProvider#assume_role_with_web_identity}
    */
    readonly assumeRoleWithWebIdentity?: CfncompatProviderAssumeRoleWithWebIdentity;
    /**
    * Default S3 bucket used for cfncompat_custom_resource response transport (the pre-signed PUT URL the custom resource handler writes its response to) when a cfncompat_custom_resource does not set its own `response_bucket`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#custom_resource_bucket CfncompatProvider#custom_resource_bucket}
    */
    readonly customResourceBucket?: string;
    /**
    * Service endpoint URL overrides, primarily for testing against LocalStack. Only used by cfncompat_custom_resource and the cfncompat data sources; the provider-defined functions make no AWS API calls.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#endpoints CfncompatProvider#endpoints}
    */
    readonly endpoints?: CfncompatProviderEndpoints;
    /**
    * URL of a proxy to use for HTTP requests when accessing the AWS API. Can also be set using the `HTTP_PROXY`/`http_proxy` environment variables.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#http_proxy CfncompatProvider#http_proxy}
    */
    readonly httpProxy?: string;
    /**
    * URL of a proxy to use for HTTPS requests when accessing the AWS API. Can also be set using the `HTTPS_PROXY`/`https_proxy` environment variables.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#https_proxy CfncompatProvider#https_proxy}
    */
    readonly httpsProxy?: string;
    /**
    * Explicitly allow the provider to perform "insecure" SSL requests. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#insecure CfncompatProvider#insecure}
    */
    readonly insecure?: boolean | cdktn.IResolvable;
    /**
    * The maximum number of times an AWS API request is retried on failure. If not set, defaults to 25.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#max_retries CfncompatProvider#max_retries}
    */
    readonly maxRetries?: number;
    /**
    * Comma-separated list of hosts that should not use HTTP or HTTPS proxies. Can also be set using the `NO_PROXY`/`no_proxy` environment variables.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#no_proxy CfncompatProvider#no_proxy}
    */
    readonly noProxy?: string;
    /**
    * The AWS profile name as set in the shared credentials/config files.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#profile CfncompatProvider#profile}
    */
    readonly profile?: string;
    /**
    * The AWS region used by cfncompat_custom_resource API calls, and reported as CloudFormation's AWS::Region by the cfncompat_pseudo_parameters data source. Can also be sourced from the `AWS_REGION`/`AWS_DEFAULT_REGION` environment variables, a shared config file, or the EC2 Instance Metadata Service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#region CfncompatProvider#region}
    */
    readonly region?: string;
    /**
    * The AWS secret key. Can also be sourced from the `AWS_SECRET_ACCESS_KEY` environment variable, or via a shared credentials file if `profile` is specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#secret_key CfncompatProvider#secret_key}
    */
    readonly secretKey?: string;
    /**
    * Paths to shared config files. If not set, defaults to `~/.aws/config`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#shared_config_files CfncompatProvider#shared_config_files}
    */
    readonly sharedConfigFiles?: string[];
    /**
    * Paths to shared credentials files. If not set, defaults to `~/.aws/credentials`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#shared_credentials_files CfncompatProvider#shared_credentials_files}
    */
    readonly sharedCredentialsFiles?: string[];
    /**
    * Skip the AWS EC2 Instance Metadata API check. Useful when running somewhere without a metadata API endpoint (setting to `true` prevents authenticating via IMDS).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#skip_metadata_api_check CfncompatProvider#skip_metadata_api_check}
    */
    readonly skipMetadataApiCheck?: boolean | cdktn.IResolvable;
    /**
    * Session token for temporary credentials, typically provided after identity federation or MFA login. Can also be sourced from the `AWS_SESSION_TOKEN` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#token CfncompatProvider#token}
    */
    readonly token?: string;
    /**
    * Alias name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#alias CfncompatProvider#alias}
    */
    readonly alias?: string;
}
export interface CfncompatProviderAssumeRole {
    /**
    * The duration of the role session, e.g. "1h". Parsed with Go's time.ParseDuration (valid units: ns, us, ms, s, m, h).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#duration CfncompatProvider#duration}
    */
    readonly duration?: string;
    /**
    * External identifier to use when assuming the role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#external_id CfncompatProvider#external_id}
    */
    readonly externalId?: string;
    /**
    * IAM policy in JSON format used as a session policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#policy CfncompatProvider#policy}
    */
    readonly policy?: string;
    /**
    * ARNs of IAM policies used as managed session policies.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#policy_arns CfncompatProvider#policy_arns}
    */
    readonly policyArns?: string[];
    /**
    * ARN of the IAM role to assume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#role_arn CfncompatProvider#role_arn}
    */
    readonly roleArn: string;
    /**
    * Session name to use when assuming the role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#session_name CfncompatProvider#session_name}
    */
    readonly sessionName?: string;
    /**
    * Source identity to use when assuming the role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#source_identity CfncompatProvider#source_identity}
    */
    readonly sourceIdentity?: string;
    /**
    * Map of assume role session tags.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#tags CfncompatProvider#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Set of assume role session tag keys to pass to any subsequent sessions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#transitive_tag_keys CfncompatProvider#transitive_tag_keys}
    */
    readonly transitiveTagKeys?: string[];
}
export declare function cfncompatProviderAssumeRoleToTerraform(struct?: CfncompatProviderAssumeRole | cdktn.IResolvable): any;
export declare function cfncompatProviderAssumeRoleToHclTerraform(struct?: CfncompatProviderAssumeRole | cdktn.IResolvable): any;
export interface CfncompatProviderAssumeRoleWithWebIdentity {
    /**
    * The duration of the role session, e.g. "1h". Parsed with Go's time.ParseDuration (valid units: ns, us, ms, s, m, h).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#duration CfncompatProvider#duration}
    */
    readonly duration?: string;
    /**
    * IAM policy in JSON format used as a session policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#policy CfncompatProvider#policy}
    */
    readonly policy?: string;
    /**
    * ARNs of IAM policies used as managed session policies.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#policy_arns CfncompatProvider#policy_arns}
    */
    readonly policyArns?: string[];
    /**
    * ARN of the IAM role to assume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#role_arn CfncompatProvider#role_arn}
    */
    readonly roleArn: string;
    /**
    * Session name to use when assuming the role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#session_name CfncompatProvider#session_name}
    */
    readonly sessionName?: string;
    /**
    * Value of a web identity token from an OIDC/OAuth provider. One of `web_identity_token` or `web_identity_token_file` is required.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#web_identity_token CfncompatProvider#web_identity_token}
    */
    readonly webIdentityToken?: string;
    /**
    * File containing a web identity token from an OIDC/OAuth provider. One of `web_identity_token_file` or `web_identity_token` is required.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#web_identity_token_file CfncompatProvider#web_identity_token_file}
    */
    readonly webIdentityTokenFile?: string;
}
export declare function cfncompatProviderAssumeRoleWithWebIdentityToTerraform(struct?: CfncompatProviderAssumeRoleWithWebIdentity | cdktn.IResolvable): any;
export declare function cfncompatProviderAssumeRoleWithWebIdentityToHclTerraform(struct?: CfncompatProviderAssumeRoleWithWebIdentity | cdktn.IResolvable): any;
export interface CfncompatProviderEndpoints {
    /**
    * Override the default EC2 service endpoint URL, used by the cfncompat_availability_zones data source. The override applies to every region, including one named by an explicit `region` argument on cfncompat_availability_zones -- the request is still signed for that region, but always sent to this endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#ec2 CfncompatProvider#ec2}
    */
    readonly ec2?: string;
    /**
    * Override the default Lambda service endpoint URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#lambda CfncompatProvider#lambda}
    */
    readonly lambda?: string;
    /**
    * Override the default S3 service endpoint URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#s3 CfncompatProvider#s3}
    */
    readonly s3?: string;
    /**
    * Override the default SNS service endpoint URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#sns CfncompatProvider#sns}
    */
    readonly sns?: string;
    /**
    * Override the default STS service endpoint URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#sts CfncompatProvider#sts}
    */
    readonly sts?: string;
}
export declare function cfncompatProviderEndpointsToTerraform(struct?: CfncompatProviderEndpoints | cdktn.IResolvable): any;
export declare function cfncompatProviderEndpointsToHclTerraform(struct?: CfncompatProviderEndpoints | cdktn.IResolvable): any;
import { CfncompatProviderFunctions } from '../provider-functions/index';
/**
* Represents a {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs cfncompat}
*/
export declare class CfncompatProvider extends cdktn.TerraformProvider {
    static readonly tfResourceType = "cfncompat";
    /**
    * Generates CDKTN code for importing a CfncompatProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CfncompatProvider to import
    * @param importFromId The id of the existing CfncompatProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CfncompatProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs cfncompat} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CfncompatProviderConfig = {}
    */
    constructor(scope: Construct, id: string, config?: CfncompatProviderConfig);
    private _accessKey?;
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    resetAccessKey(): void;
    get accessKeyInput(): string | undefined;
    private _assumeRole?;
    get assumeRole(): CfncompatProviderAssumeRole | undefined;
    set assumeRole(value: CfncompatProviderAssumeRole | undefined);
    resetAssumeRole(): void;
    get assumeRoleInput(): CfncompatProviderAssumeRole | undefined;
    private _assumeRoleWithWebIdentity?;
    get assumeRoleWithWebIdentity(): CfncompatProviderAssumeRoleWithWebIdentity | undefined;
    set assumeRoleWithWebIdentity(value: CfncompatProviderAssumeRoleWithWebIdentity | undefined);
    resetAssumeRoleWithWebIdentity(): void;
    get assumeRoleWithWebIdentityInput(): CfncompatProviderAssumeRoleWithWebIdentity | undefined;
    private _customResourceBucket?;
    get customResourceBucket(): string | undefined;
    set customResourceBucket(value: string | undefined);
    resetCustomResourceBucket(): void;
    get customResourceBucketInput(): string | undefined;
    private _endpoints?;
    get endpoints(): CfncompatProviderEndpoints | undefined;
    set endpoints(value: CfncompatProviderEndpoints | undefined);
    resetEndpoints(): void;
    get endpointsInput(): CfncompatProviderEndpoints | undefined;
    private _httpProxy?;
    get httpProxy(): string | undefined;
    set httpProxy(value: string | undefined);
    resetHttpProxy(): void;
    get httpProxyInput(): string | undefined;
    private _httpsProxy?;
    get httpsProxy(): string | undefined;
    set httpsProxy(value: string | undefined);
    resetHttpsProxy(): void;
    get httpsProxyInput(): string | undefined;
    private _insecure?;
    get insecure(): boolean | cdktn.IResolvable | undefined;
    set insecure(value: boolean | cdktn.IResolvable | undefined);
    resetInsecure(): void;
    get insecureInput(): boolean | cdktn.IResolvable | undefined;
    private _maxRetries?;
    get maxRetries(): number | undefined;
    set maxRetries(value: number | undefined);
    resetMaxRetries(): void;
    get maxRetriesInput(): number | undefined;
    private _noProxy?;
    get noProxy(): string | undefined;
    set noProxy(value: string | undefined);
    resetNoProxy(): void;
    get noProxyInput(): string | undefined;
    private _profile?;
    get profile(): string | undefined;
    set profile(value: string | undefined);
    resetProfile(): void;
    get profileInput(): string | undefined;
    private _region?;
    get region(): string | undefined;
    set region(value: string | undefined);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _secretKey?;
    get secretKey(): string | undefined;
    set secretKey(value: string | undefined);
    resetSecretKey(): void;
    get secretKeyInput(): string | undefined;
    private _sharedConfigFiles?;
    get sharedConfigFiles(): string[] | undefined;
    set sharedConfigFiles(value: string[] | undefined);
    resetSharedConfigFiles(): void;
    get sharedConfigFilesInput(): string[] | undefined;
    private _sharedCredentialsFiles?;
    get sharedCredentialsFiles(): string[] | undefined;
    set sharedCredentialsFiles(value: string[] | undefined);
    resetSharedCredentialsFiles(): void;
    get sharedCredentialsFilesInput(): string[] | undefined;
    private _skipMetadataApiCheck?;
    get skipMetadataApiCheck(): boolean | cdktn.IResolvable | undefined;
    set skipMetadataApiCheck(value: boolean | cdktn.IResolvable | undefined);
    resetSkipMetadataApiCheck(): void;
    get skipMetadataApiCheckInput(): boolean | cdktn.IResolvable | undefined;
    private _token?;
    get token(): string | undefined;
    set token(value: string | undefined);
    resetToken(): void;
    get tokenInput(): string | undefined;
    private _alias?;
    get alias(): string | undefined;
    set alias(value: string | undefined);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _functions?;
    /**
    * Provider-defined functions of the cfncompat provider.
    */
    get functions(): CfncompatProviderFunctions;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
