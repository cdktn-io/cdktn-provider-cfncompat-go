/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CustomResourceConfig extends cdktn.TerraformMetaArguments {
    /**
    * CloudFormation-style logical resource id reported in the request event's `LogicalResourceId` field. Typically set by a CDK Terrain synthesis backend to the synthesized CloudFormation logical id; defaults to `"CfncompatCustomResource"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs/resources/custom_resource#logical_resource_id CustomResource#logical_resource_id}
    */
    readonly logicalResourceId?: string;
    /**
    * Arbitrary user-defined properties passed to the handler as the request event's `ResourceProperties`. May be an object/map (arbitrarily nested) or omitted entirely. CloudFormation merges `ServiceToken` into this map when delivering it to the handler; this resource replicates that behavior.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs/resources/custom_resource#resource_properties CustomResource#resource_properties}
    */
    readonly resourceProperties?: {
        [key: string]: any;
    };
    /**
    * CloudFormation resource type name reported in the request event's `ResourceType` field. Defaults to `"AWS::CloudFormation::CustomResource"`. May also be set to `Custom::<name>` (matching CloudFormation's convention for named custom resource types), where `<name>` matches `^[A-Za-z0-9_@-]{1,52}$` and the full value is at most 60 characters. Changing this forces replacement: CloudFormation forbids changing a custom resource's type in an update.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs/resources/custom_resource#resource_type CustomResource#resource_type}
    */
    readonly resourceType?: string;
    /**
    * S3 bucket used for this resource's response transport (the pre-signed PUT URL the handler writes its response to). Falls back to the provider's `custom_resource_bucket` if unset; it is an error at apply time if neither is set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs/resources/custom_resource#response_bucket CustomResource#response_bucket}
    */
    readonly responseBucket?: string;
    /**
    * Optional S3 key prefix for the response object. The full key is `"<response_key_prefix>cfncompat/<RequestId>.json"` -- include a trailing `/` if you want the prefix to behave like a folder.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs/resources/custom_resource#response_key_prefix CustomResource#response_key_prefix}
    */
    readonly responseKeyPrefix?: string;
    /**
    * Seconds to wait for the handler's response before failing, mirroring CloudFormation's `ServiceTimeout`. Must be between 1 and 3600 (CloudFormation's own range). Defaults to `3600`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs/resources/custom_resource#service_timeout CustomResource#service_timeout}
    */
    readonly serviceTimeout?: number;
    /**
    * ARN of the Lambda function or SNS topic that implements the custom resource handler (CloudFormation's `ServiceToken`). Must be a Lambda function ARN (`arn:*:lambda:...`, invoked asynchronously) or an SNS topic ARN (`arn:*:sns:...`, published to).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs/resources/custom_resource#service_token CustomResource#service_token}
    */
    readonly serviceToken: string;
    /**
    * CloudFormation-style stack identifier reported in the request event's `StackId` field, passed through verbatim. Typically set by a CDK Terrain synthesis backend to a stack identifier; defaults to `"cfncompat/no-stack-id"`.
    *
    * ~> That default is a **shared sentinel**: every `cfncompat_custom_resource` in the workspace that leaves `stack_id` unset sends the same value. Handlers that treat `StackId` as an ownership key then cannot tell one stack's objects from another's -- CDK's S3 notifications handler, for instance, prefixes every notification `Id` with `{StackId}-` and, on delete, removes exactly the notifications carrying that prefix, so two stacks sharing the sentinel would delete each other's notifications. Wire this to `data.cfncompat_pseudo_parameters.<name>.stack_id` with `stack_name` set (that value is deterministic and stable across applies); leaving it unset emits a warning today and is planned to become an error in v1.0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs/resources/custom_resource#stack_id CustomResource#stack_id}
    */
    readonly stackId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs/resources/custom_resource cfncompat_custom_resource}
*/
export declare class CustomResource extends cdktn.TerraformResource {
    static readonly tfResourceType = "cfncompat_custom_resource";
    /**
    * Generates CDKTN code for importing a CustomResource resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CustomResource to import
    * @param importFromId The id of the existing CustomResource that should be imported. Refer to the {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs/resources/custom_resource#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CustomResource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs/resources/custom_resource cfncompat_custom_resource} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CustomResourceConfig
    */
    constructor(scope: Construct, id: string, config: CustomResourceConfig);
    private _data;
    get data(): cdktn.AnyMap;
    get id(): string;
    private _logicalResourceId?;
    get logicalResourceId(): string;
    set logicalResourceId(value: string);
    resetLogicalResourceId(): void;
    get logicalResourceIdInput(): string | undefined;
    get physicalResourceId(): string;
    private _resourceProperties?;
    get resourceProperties(): {
        [key: string]: any;
    };
    set resourceProperties(value: {
        [key: string]: any;
    });
    resetResourceProperties(): void;
    get resourcePropertiesInput(): {
        [key: string]: any;
    } | undefined;
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    resetResourceType(): void;
    get resourceTypeInput(): string | undefined;
    private _responseBucket?;
    get responseBucket(): string;
    set responseBucket(value: string);
    resetResponseBucket(): void;
    get responseBucketInput(): string | undefined;
    private _responseKeyPrefix?;
    get responseKeyPrefix(): string;
    set responseKeyPrefix(value: string);
    resetResponseKeyPrefix(): void;
    get responseKeyPrefixInput(): string | undefined;
    private _serviceTimeout?;
    get serviceTimeout(): number;
    set serviceTimeout(value: number);
    resetServiceTimeout(): void;
    get serviceTimeoutInput(): number | undefined;
    private _serviceToken?;
    get serviceToken(): string;
    set serviceToken(value: string);
    get serviceTokenInput(): string | undefined;
    private _stackId?;
    get stackId(): string;
    set stackId(value: string);
    resetStackId(): void;
    get stackIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
