/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCfncompatAvailabilityZonesConfig extends cdktn.TerraformMetaArguments {
    /**
    * The region to list Availability Zones for, i.e. the `Fn::GetAZs` argument. An empty string or an unset value means the provider's own region -- exactly as [the `Fn::GetAZs` reference](https://docs.aws.amazon.com/AWSCloudFormation/latest/TemplateReference/intrinsic-function-reference-getavailabilityzones.html) specifies that "specifying an empty string is equivalent to specifying `AWS::Region`". Echoed back as the region that was actually queried.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs/data-sources/availability_zones#region DataCfncompatAvailabilityZones#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs/data-sources/availability_zones cfncompat_availability_zones}
*/
export declare class DataCfncompatAvailabilityZones extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cfncompat_availability_zones";
    /**
    * Generates CDKTN code for importing a DataCfncompatAvailabilityZones resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCfncompatAvailabilityZones to import
    * @param importFromId The id of the existing DataCfncompatAvailabilityZones that should be imported. Refer to the {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs/data-sources/availability_zones#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCfncompatAvailabilityZones to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cdktn-io/cfncompat/0.3.0/docs/data-sources/availability_zones cfncompat_availability_zones} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCfncompatAvailabilityZonesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCfncompatAvailabilityZonesConfig);
    get allNames(): string[];
    get id(): string;
    get names(): string[];
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get zoneIds(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
